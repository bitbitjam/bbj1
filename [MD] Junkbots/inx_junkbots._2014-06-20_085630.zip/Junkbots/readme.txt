�Qu� diablos!

El tema de la #bitbitjam ha sido manipulado. Los Mojones han escondido las seis evidencias de la conspiraci�n, y t� debes buscarlas.

Ayuda a Leobot a encontrar las pruebas de la manipulaci�n.




What the heck!

The theme of the #bitbitjam has been manipulated. The Mojon have hidden six evidences of conspiracy and you must find them.

Support Leobot find evidence of manipulation.