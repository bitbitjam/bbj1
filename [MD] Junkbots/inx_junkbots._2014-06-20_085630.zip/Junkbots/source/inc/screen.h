
void screen_title    ( );
void screen_sega     ( u16 secs, u16 buttons, u8 on_release  );
void screen_gameover ( bool congrats );
