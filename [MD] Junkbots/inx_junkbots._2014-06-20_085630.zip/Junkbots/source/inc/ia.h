#define IA_MAX_DEPTH        5

void ia_enemy();
