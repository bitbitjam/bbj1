u16  sd_new    ( );
void sd_delete ( u16 i );
void sd_reset  ( );
