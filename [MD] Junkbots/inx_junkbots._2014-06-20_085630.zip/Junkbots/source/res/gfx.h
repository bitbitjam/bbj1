#ifndef _GFX_H_
#define _GFX_H_

extern const Image bgb_image;
extern const Image title_image;
extern const Image gameover_image;
extern const SpriteDefinition leo;
extern const TileSet tileset;
extern const Palette tilespal;

#endif // _GFX_H_
